# Azur Park — Plateforme HSE 2026

Plateforme web autonome de pilotage de la sécurité — DUERP 2026 consolidé.

## Déploiement Vercel — 2 méthodes

### Méthode 1 (la plus simple) — Drag & Drop
1. Aller sur https://vercel.com/new
2. Glisser-déposer le fichier `index.html` dans la zone d'import
3. Cliquer "Deploy" — l'URL est générée en 30 secondes

### Méthode 2 — CLI Vercel (depuis ce dossier)
```bash
npm install -g vercel
vercel login          # se connecter à votre compte
vercel --prod         # déployer en production
```

## Contenu

- `index.html` — site complet autonome (282 Ko)
- `vercel.json` — configuration sécurité headers
- `README.md` — ce fichier

## Mise à jour

Pour mettre à jour le site, remplacer `index.html` puis redéployer.
